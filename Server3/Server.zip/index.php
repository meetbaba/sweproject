<?php
  $conn=mysqli_connect("localhost", "sweyoon", yoonsung);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

  mysqli_select_db($conn, 'sweyoon');
  // $result_conection=mysqli_query($conn, "CREATE DATABASE sample CHARACTER SET utf8 COLLATE utf8_general_ci")

  $result_creat_table=mysqli_query($conn, "CREATE TABLE sample1 (
id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  vehicle_code int(10) NOT NULL,
  raspberrypi_ip varchar(46) NOT NULL,
  user_id varchar(30),
  user_mac varchar(30)
) ENGINE=InnoDB DEFAULT CHARSET=utf8");

  $result = mysqli_query($conn, "SELECT * FROM sample1");


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
  <title>Vehicle Code Mapping Manager</title>
  <link rel="stylesheet" type="text/css" href="http://localhost/SWE/style.css">
</head>
<body>
  <p>
    <b>
      <main>
        Vehicle Code Mapping Manager
      </main>
    </b>
  </p>

  <p>
    <ul>
      <?php
        while($row = mysqli_fetch_assoc($result)){
          echo '<textarea name="TA_vehicle_code_list_"'.$row['id'].' rows="8" cols="40">'.$row['vehicle_code'].'</textarea><textarea name="TA_raspberrypi_ip_list_"'.$row['id'].' rows="8" cols="40">'.$row['raspberrypi_ip'].'</textarea>';
        }
      ?>

    </ul>

  </p>



</body>
</html>
